-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 18 Bulan Mei 2020 pada 03.11
-- Versi server: 10.4.8-MariaDB
-- Versi PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tubes_pw_193040018`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `buku`
--

CREATE TABLE `buku` (
  `No` int(11) NOT NULL,
  `gambar` varchar(200) NOT NULL,
  `judu_buku` varchar(200) NOT NULL,
  `penulis` varchar(200) NOT NULL,
  `penerbit` varchar(100) NOT NULL,
  `tebal_buku` varchar(100) NOT NULL,
  `tahun_terbit` int(11) NOT NULL,
  `deskripsi_buku` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `buku`
--

INSERT INTO `buku` (`No`, `gambar`, `judu_buku`, `penulis`, `penerbit`, `tebal_buku`, `tahun_terbit`, `deskripsi_buku`) VALUES
(1, 'naruto.jpg', 'NARUTO', 'Masashi Kishimoto', 'Elex Media Komputindo', '216 Halaman', 1999, 'Naruto (ナルト) adalah sebuah serial manga karya Masashi Kishimoto yang diadaptasi menjadi serial anime. Manga Naruto bercerita seputar kehidupan tokoh utamanya, Naruto Uzumaki, seorang ninja yang hiperaktif, periang, dan ambisius yang ingin mewujudkan keinginannya untuk mendapatkan gelar Hokage, pemimpin dan ninja terkuat di desanya. Serial ini didasarkan pada komik one-shot oleh Kishimoto yang diterbitkan dalam edisi Akamaru Jump pada Agustus 1997.[1]\r\n\r\nManga Naruto pertama kali diterbitkan di J'),
(2, 'boruto.jpg', 'BORUTO ', 'Ukyō Kodachi', 'Viz Media', '360 Halaman', 2016, 'BORUTO-ボルト- -NARUTO NEXT GENERATIONS-, adalah sebuah seri manga shōnen Jepang yang ditulis oleh Ukyō Kodachi dan diilustrasikan oleh Mikio Ikemoto. Manga ini dimuat dalam majalah manga Weekly Shōnen Jump terbitan Shueisha sebelum dipindahkan ke majalah lain milik Shueisha berjudul V Jump pada tahun 2019. Seri ini juga merupakan cerita spin-off dan sekuel dari manga Naruto karya Masashi Kishimoto, yang mengisahkan kehidupan putra Naruto Uzumaki, Boruto Uzumaki, dan kelompok ninjanya.'),
(3, 'dragonball.jpg', 'DRAGON BALL', 'Akira Toriyama', 'Shueisha', '529 Halaman', 1986, 'Dragon Ball ( Jepang : ド ラ ゴ ン ボ ー ル , Hepburn : Doragon Bōru ) adalah seri manga jepang yang diulis dan di ilustrasikan oleh akira toriyama.Awalnya memiliki fokus komedi tetapi kemudian menjadi seri pertempuran penuh aksi. Ceritanya mengikuti petualangan Son Goku , dari masa kanak-kanak hingga dewasa, saat ia berlatih seni bela diri dan menjelajahi dunia untuk mencari Bola Naga, tujuh bola ajaib yang memanggil naga yang menginginkan keinginan ketika berkumpul.'),
(4, 'onepiece.jpg', 'ONE PIECE', 'Eiichiro Oda', 'Viz Media', '524 Halaman', 1997, 'One Piece (bahasa Jepang: ワンピース Hepburn: Wan Pīsu) adalah sebuah seri manga Jepang yang ditulis dan diilustrasikan oleh Eiichiro Oda. Manga ini telah dimuat di majalah Weekly Shōnen Jump milik Shueisha sejak tanggal 22 Juli 1997, dan telah dibundel menjadi 91 volume tankōbon. Ceritanya mengisahkan petualangan Monkey D. Luffy, seorang anak laki-laki yang memiliki kemampuan tubuh elastis seperti karet setelah memakan Buah Iblis secara tidak disengaja.'),
(5, 'onepunchman.jpg', 'ONE-PUNCH MAN', 'One', 'Shueisha', '223 Halaman', 2009, 'One-Punch Man ( ワンパンマン Wanpanman) adalah sebuah serial manga Jepang yang menceritakan seorang superhero yang bernama Saitama. One-Punch Man dibuat oleh seorang penulis yang asal jepang dengan nama samaran ONE yang mulai diterbitkan pada awal tahun 2009. Serial ini segera menjadi viral sehingga mampu melampaui 7,9 juta hits pada bulan Juni 2012. One-Punch Man merupakan kontraksi wanpanchi (\"One-Punch\") yang artinya satu pukulan'),
(6, 'conan.jpg', 'DETEKTIF CONAN', 'Gosho Aoyama', 'Shogakukan', '104 Halaman', 1994, 'eitantei Konan (bahasa Jepang: 名探偵コナン), yang juga dikenal sebagai Case Closed atau Detective Conan, dan telah diterbitkan di Indonesia dengan judul Detektif Conan,adalah sebuah seri manga shōnen Jepang bertema detektif yang ditulis dan diilustrasikan oleh Gosho Aoyama. Manga ini telah dimuat dalam majalah Weekly Shōnen Sunday terbitan Shogakukan sejak tanggal 19 Januari 1994, dan telah dibundel menjadi 96 volume tankōbon hingga tanggal 10 April 2019.'),
(7, 'fairytail.jpg', 'FAIRY TAIL', 'Hiro Mashima', 'Del Rey Manga', '412 Halaman', 2006, 'Fairy Tail (bahasa Jepang: フェアリーテイル Hepburn: Fearī Teiru) adalah sebuah seri manga shōnen Jepang yang ditulis dan diilustrasikan oleh Hiro Mashima. Manga ini dimuat berseri dalam majalah Weekly Shōnen Magazine sejak bulan Agustus 2006 hingga Juli 2017, dan telah diterbitkan menjadi 63 volume tankōbon oleh Kodansha. Ceritanya mengisahkan tentang Natsu Dragneel, anggota dari guild penyihir populer bernama Fairy Tail, yang bertualang di Earth-land dalam tujuannya untuk mencari seekor naga '),
(8, 'attackontitan.jpg', 'ATTACK ON TITAN', 'Hajime Isayama', 'Kodansha USA', '260 Halaman', 2009, 'Shingeki no Kyojin (bahasa Jepang: 進撃の巨人, terj. har. \"Raksasa [yang] Menyerang\"), yang diterbitkan di Indonesia dengan judul Attack on Titan, adalah sebuah seri manga shōnen Jepang yang ditulis dan diilustrasikan oleh Hajime Isayama. Ceritanya berlatar di dunia fantasi tempat umat manusia hidup di wilayah yang dikelilingi tiga lapis tembok besar, yang melindungi mereka dari makhluk pemakan manusia berukuran raksasa yang dikenal sebagai Titan.'),
(9, 'bleach.jpg', 'BLEACH', 'Tite Kubo', 'M&C!', '111 Halaman', 2001, 'Bleach (bahasa Jepang: ブリーチ Hepburn: Burīchi) adalah sebuah seri manga shōnen Jepang yang ditulis dan diilustrasikan oleh Tite Kubo. Alur ceritanya mengisahkan petualangan remaja keras kepala bernama Ichigo Kurosaki yang mewarisi takdir orang tuanya, setelah dia mendapatkan kekuatan Shinigami (死神 Shinigami, terj. har. \"Dewa Kematian\")—sebuah personifikasi kematian yang mirip dengan Malaikat Maut—dari Shinigami lainnya, Rukia Kuchiki.'),
(10, 'tokyoghoul.jpg', 'TOKYO GHOUL', 'Sui Ishida', 'Shueisha', '350 Halaman', 2011, 'Tokyo Ghoul (bahasa Jepang: 東京喰種トーキョーグール Hepburn: Tōkyō Gūru) adalah sebuah seri manga seinen Jepang bergenre fantasi gelap yang ditulis dan diilustrasikan oleh Sui Ishida. Manga ini mulai dimuat dalam majalah Weekly Young Jump terbitan Shueisha sejak bulan September 2011 hingga September 2014, dan telah dibundel menjadi empat belas volume tankōbon hingga bulan Agustus 2014. ');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(10, 'pw', '$2y$10$Ozqdz8FDHJpi3dZbsDWyh.Ugo6j7nE3vh3SPUWEUa7e0kMbYoWLY2'),
(11, 'admin', '$2y$10$RcuHWrBswFDDNISQ.wwjkOjVe4tOpCNjhaxVpF60Q/QSyw32.Jcme');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`No`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `buku`
--
ALTER TABLE `buku`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
