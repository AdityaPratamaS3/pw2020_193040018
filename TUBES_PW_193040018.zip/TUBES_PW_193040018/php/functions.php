<?php

function koneksi()
{
  //koneksi ke DB $ pilih database
  return mysqli_connect('localhost', 'root', '', 'tubes_pw_193040018');
}

function query($query)
{
  $conn = koneksi();
  //query isi tabel buku
  $result = mysqli_query($conn, $query);

  //jika hasilnya hanya satu data
  if (mysqli_num_rows($result) == 1) {
    return mysqli_fetch_assoc($result);
  }


  //ubah data ke dalam array
  $rows = [];
  while ($row = mysqli_fetch_assoc($result)) {
    $rows[] = $row;
  }
  return $rows;
}

function tambah($data)
{
  $conn = koneksi();


  $gambar =  htmlspecialchars($data['gambar']);
  $judu_buku =  htmlspecialchars($data['judu_buku']);
  $penulis =  htmlspecialchars($data['penulis']);
  $penerbit =  htmlspecialchars($data['penerbit']);
  $tebal_buku =  htmlspecialchars($data['tebal_buku']);
  $tahun_terbit =  htmlspecialchars($data['tahun_terbit']);
  $deskripsi_buku =  htmlspecialchars($data['deskripsi_buku']);


  $query = "INSERT  INTO 
            buku
            VALUES
            (null,'$gambar','$judu_buku',' $penulis',' $penerbit','$tebal_buku',' $tahun_terbit',' $deskripsi_buku');
          ";
  mysqli_query($conn, $query);
  echo mysqli_error($conn);
  return mysqli_affected_rows($conn);
}

function login($data)
{
  $conn = koneksi();

  $username = htmlspecialchars($data['username']);
  $password = htmlspecialchars($data['password']);

  //cek username

  if ($user = query("SELECT * FROM user WHERE username = '$username'")) {
    //cek password
    if (password_verify($password, $user['password'])) {
      //set session
      $_SESSION['login'] = true;
      header("Location:../php/admin.php");
      exit;
    }
  }
  return [
    'error' => true,
    'pesan' => 'Username/Password Salah!'
  ];
}

function registrasi($data)
{
  $conn = koneksi();
  $username = htmlspecialchars(strtolower($data['username']));
  $password1 = mysqli_real_escape_string($conn, $data['password1']);
  $password2 = mysqli_real_escape_string($conn, $data['password2']);

  //jika username / password kosong
  if (empty($username) || empty($password1) || empty($password2)) {
    echo "<script>
        alert('username / password tidak boleh kosong!');
        document.location.href='../php/registrasi.php';
      </script>";

    return false;
  }
  //jika usernmae sudah ada
  if (query("SELECT * FROM user WHERE username = '$username'")) {
    echo "<script>
    alert('username sudah terdaftar!');
    document.location.href='../php/registrasi.php';
  </script>";
  }
  //jika konfirmasi password tidak sesuai
  if ($password1 !== $password2) {
    echo "<script>
  alert('Konfirmasi password tidak sesuai!');
  document.location.href='../php/registrasi.php';
</script>";
  }

  //jika password <5 digit
  if (strlen($password1) < 5) {
    echo "<script>
    alert('password terlalu pendek!');
    document.location.href='../php/registrasi.php';
  </script>";
  }
  //jika username dan password sudah sesuai
  //enkripsi password
  $password_baru = password_hash($password1, PASSWORD_DEFAULT);
  //insert ke tabel user
  $query = "INSERT INTO user
            VALUES
            (null,'$username','$password_baru')
            ";

  mysqli_query($conn, $query) or die(mysqli_error($conn));
  return mysqli_affected_rows($conn);
}

//cari
function cari($keyword)
{
  $conn = koneksi();

  $query = "SELECT * FROM buku 
  WHERE 
  judu_buku LIKE '%$keyword%' OR
  penulis LIKE '%$keyword%' OR
  penerbit LIke '%$keyword%' OR
  tebal_buku LIKE '%$keyword%' OR
  tahun_terbit LIKe '%$keyword%'
  ";
  $result = mysqli_query($conn, $query);

  $rows = [];
  while ($row = mysqli_fetch_assoc($result)) {
    $rows[] = $row;
  }
  return $rows;
}
