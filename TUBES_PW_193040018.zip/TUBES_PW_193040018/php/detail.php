<?php
require '../php/functions.php';
$buku = query("SELECT * FROM buku");
?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <!-- mycss -->
  <link rel="stylesheet" href="../css/css/mycss.css">
  <title>Front-end</title>

</head>

<body class="page-top">
  <!-- slider -->

  <!-- akhir slider -->
  <!-- navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href=""><img src="../assets/img/logo2.png">E-Manga:漫画</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span><a class="nav-link" href="../index/index.php">Home <span class="sr-only">(current)</span></a></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="../index/index.php">Home <span class="sr-only">(current)</span></a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- akhir navbar -->
  <table border="1" cellpadding="13" cellspacing="0" class="striped">
    <br>
    <tr>
      <th>No</th>
      <th>Gambar</th>
      <th>Judul_Buku</th>
      <th>Deskripsi_Buku</th>
    </tr>
    <?php $i = 1; ?>
    <?php foreach ($buku as $bk) : ?>
      <tr>
        <td><?= $i++; ?></td>
        <td><img src="../assets/img/<?= $bk['gambar']; ?>" alt="" width="100"></td>
        <td><?= $bk['judu_buku']; ?></td>
        <td><?= $bk['deskripsi_buku']; ?></td>
      </tr>
    <?php endforeach; ?>
  </table>
</body>
<!-- footer -->
<footer>
  <nav class="navbar-fixed-bottom">
    <div class="container text-center">
      <div class="row">
        <div class="col-sm-12">
          <p>copyright &copy; 2020 | built by. <a href="https://www.instagram.com/it.sme_radit/?hl=id">Aditya Pratama S</a>.</p>
        </div>
      </div>
    </div>
  </nav>
</footer>
<!-- akhir footer -->


<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

</html>