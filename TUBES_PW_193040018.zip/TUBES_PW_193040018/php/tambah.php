<?php
require '../php/functions.php';

if (isset($_POST['tambah'])) {
  if (tambah($_POST) > 0) {
    echo "<script>
              alert('data berhasil ditambahkan');
              document.location.href='../php/admin.php';
          </script>";
  } else {
    echo "data gagal ditambahkan!";
  }
}
?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <!-- mycss -->
  <link rel="stylesheet" href="../css/css/mycss.css">
  <title>Back-end</title>

</head>

<body class="page-top">
  <!-- navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href=""><img src="../assets/img/logo2.png">E-Manga:漫画</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span><a class="nav-link" href="../php/admin.php">Back<span class="sr-only">(current)</span></a></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="../php/admin.php">Back<span class="sr-only">(current)</span></a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- akhir navbar -->
  <h3>Form Tambah data</h3>

  <body>
    <br><br>
    <form action="" method="POST" class="text-primary">
      <ul>
        <li>
          <label for="gambar">Gambar :</label><br><br>
          <input type="text" name="gambar" autofocus required>
        </li>
        <li>
          <label for="judu_buku">Judul_Buku :</label><br><br>
          <input type="text" name="judu_buku" required>
        </li>
        <li>
          <label for="penulis">Penulis :</label><br><br>
          <input type="text" name="penulis" required>
        </li>
        <li>
          <label for="penerbit">Penerbit :</label><br><br>
          <input type="text" name="Penerbit" required>
        </li>
        <li>
          <label for="tebal_buku">Tebal_Buku :</label><br><br>
          <input type="text" name="tebal_buku" required>
        </li>
        <li>
          <label for="tahun-terbit">Tahun_Terbit :</label><br><br>
          <input type="text" name="tahun_terbit" required>
        </li>
        <li>
          <label for="deskripsi_buku">deskripsi_buku :</label><br><br>
          <input type="text" name="deskripsi_buku" required>
        </li>
        <li>
          <button type="submit" name="tambah" class="btn btn-primary">Add Data!</button>
        </li>
      </ul>
    </form>
  </body>
  </table>
  <!-- footer -->
  <footer>
    <nav class="navbar-fixed-bottom">
      <div class="container text-center">
        <div class="row">
          <div class="col-sm-12">
            <p>copyright &copy; 2020 | built by. <a href="https://www.instagram.com/it.sme_radit/?hl=id">Aditya Pratama S</a>.</p>
          </div>
        </div>
      </div>
    </nav>
  </footer>
  <!-- akhir footer -->

  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  <!-- my js -->
  <script src="../css/js/myjava.js">
  </script>
  <!-- akhir js -->
</body>

</html>