<?php
require '../php/functions.php';
//ketika tombol login ditekan
if (isset($_POST['registrasi'])) {
  if (registrasi($_POST) > 0) {
    echo "<script>
    alert('user baru berhasil ditambahkan.silahkan login!');
    document.location.href='../php/login.php';
  </script>";
  } else {
    echo "user gagal ditambahkan";
  }
}
?>


<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <!-- mycss -->
  <link rel="stylesheet" href="../css/css/mycss.css">
  <title>Back-end</title>

</head>

<body class="page-top">
  <!-- navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href=""><img src="../assets/img/logo2.png">E-Manga:漫画</a>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
        </ul>
      </div>
    </div>
  </nav>
  <!-- akhir navbar -->

  <body>
    <br><br><br>
    <?php if (isset($login['error'])) : ?>
      <p style="color: red; font-style:italic;"><?= $login['pesan']; ?></p>
    <?php endif; ?>
    <form action="" method="POST">
      <ul>
        <li>
          <label class="text-primary">
            Username : <br>
            <input type="text" name="username" autofocus autocomplete="off" required>
          </label>
        </li>
        <li>
          <label class="text-primary">
            Password : <br>
            <input type="password" name="password1" required>
          </label>
        </li>
        <li>
          <label class="text-primary">
            confirm password : <br>
            <input type="password" name="password2" required>
          </label>
        </li>
        <li>
          <button name="registrasi" type="submit" class="btn btn-primary">Registrasi</button>
          <a href="../php/login.php" class="btn btn-primary">Back</a>
        </li>
      </ul>
    </form>
  </body>
  </table>
  <br><br><br><br><br><br><br><br><br> <br><br><br>
  <!-- footer -->
  <footer>
    <nav class="navbar-fixed-bottom">
      <div class="container text-center">
        <div class="row">
          <div class="col-sm-12">
            <p>copyright &copy; 2020 | built by. <a href="https://www.instagram.com/it.sme_radit/?hl=id">Aditya Pratama S</a>.</p>
          </div>
        </div>
      </div>
    </nav>
  </footer>
  <!-- akhir footer -->

  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  <!-- my js -->
  <script src="../css/js/myjava.js">
  </script>
  <!-- akhir js -->
</body>

</html>