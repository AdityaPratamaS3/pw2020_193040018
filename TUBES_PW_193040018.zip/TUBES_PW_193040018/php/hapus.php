<?php
session_start();
if (isset($_SESSION['login'])) {
  header("Location:../php/login.php");
  exit;
}
require '../php/functions.php';
